

<?php $__env->startSection('title'); ?>
    Statistik Deskriptif
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat-aktif'); ?>
    Statistik Deskriptif
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content mt-2">
        <div class="container-fluid">
            <div class="row justify-content-center">              

                <div class="col-lg-7">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                <p class="h3">Silahkan Masukkan Skor</p>                  
                            </div>
                        </div>
                        <div class="card-body">                
                            <form method="post" action="/" id="forminput">                           
                                <div class="form-group">
                                    <label for="input2">Skor</label>
                                    <input type="text" class="form-control mb-2"
                                        placeholder="Masukkan Skor" name="skor" value="<?php echo e(old('skor')); ?>">

                                        <?php if($errors->has('skor')): ?>
                                            <div class="alert alert-danger"><?php echo e($errors->first('skor')); ?></div>
                                        <?php endif; ?>
                                        
                                        <?php if($errors->has('file')): ?>
                                            <div class="alert alert-danger"><?php echo e($errors->first('file')); ?></div>
                                        <?php endif; ?>

                                        <?php if(session('error')): ?>
                                            <div class="alert alert-danger"><?php echo e(session('error')); ?> </div>
                                        <?php endif; ?>

                                </div>
                                <input type="submit" class="btn btn-primary daftar-btn mt-4" name="submit" value="Input">  

                                <?php echo csrf_field(); ?>
                                
                                <?php if(session('status')): ?>
                                    <p></p>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>

                            </form>                
                        </div>
                    </div>                              
                </div>

                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                <p class="h3">Data Skor</p> 
                                
                            </div>
                        </div>
                        <div class="card-body">                
                            <table class="table">
                                <thead>
                                    <tr>
                                        <td scope="col">No</td>                
                                        <td scope="col">Skor</td>
                                        <td scope="col">Action</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>                             
                                        <th scope="row"><?php echo e(($users->currentpage()-1) * $users->perpage() + $loop->index + 1); ?></th>                     
                                        <td><?php echo e($user->skor); ?></td>
                                        <td>
                                            <form name="delete" action="/delete/<?php echo e($user->id); ?>" method="POST">     
                                                <a href='/edit/<?php echo e($user->id); ?>' class="btn btn-outline-success">Edit</a> 
                                                <?php echo csrf_field(); ?>               
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-outline-danger">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                          
                                </tbody>
                                
                            </table>
                            <div class="mt-4 col-12 d-flex justify-content-center">
                                <?php echo e($users->links("pagination::bootstrap-4")); ?>                       
                            </div>
                        </div>
                    </div>
                    <!-- /.card -->                
                </div>
                

                                                                 
                
            </div>                                        
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>
                                       

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\latihanlaravel\resources\views//home.blade.php ENDPATH**/ ?>