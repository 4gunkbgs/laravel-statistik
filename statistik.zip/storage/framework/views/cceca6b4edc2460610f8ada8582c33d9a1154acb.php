

<?php $__env->startSection('title'); ?>
    Frekuensi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat-aktif'); ?>
    Statistik Deskriptif / Frekuensi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-6">                                                                                                 
            <div class="card">
                <div class="card-header border-0">
                    <p class="h3">Tabel Frekuensi</p>                
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-striped table-valign-middle">
                        <thead>
                            <tr>
                                <th>Skor</th>
                                <th>Frekuensi</th>                    
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $frekuensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td> <?php echo e($skor->skor); ?> </td>
                                <td> <?php echo e($skor->frekuensi); ?></td>
                            </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="col"> <b>Total Frekuensi:</b>  </td>
                                <td> <?php echo e($totalfrekuensi); ?></td>  
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>                        
        </div>                      
    </div>

<?php $__env->stopSection(); ?>                
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\latihanlaravel\resources\views/frekuensi.blade.php ENDPATH**/ ?>