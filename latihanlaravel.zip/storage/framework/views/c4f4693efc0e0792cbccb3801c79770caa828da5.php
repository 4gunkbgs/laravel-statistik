

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-8">
                <form method="POST" action="/edit/<?php echo e($anggota->id); ?>" class="bg-white form-container" id="forminput">   
                <?php echo csrf_field(); ?>                   
                <?php echo method_field('PUT'); ?>
                    <h2>Edit Data <?php echo e($anggota->nama); ?></h2>
                    <br />
                    
                    <div class="form-group">
                        <label for="input1">Nama Mahasiswa</label>
                        <input type="text" class="form-control" value="<?php echo e($anggota->nama); ?>" id="nama"
                            placeholder="Nama Mahasiswa" name="nama" required />
                    </div>  
                    <div class="form-group">
                        <label for="input2">Skor</label>
                        <input type="text" class="form-control" value="<?php echo e($anggota->skor); ?>" id="skor"
                            placeholder="Skor" name="skor" required />
                    </div>                
                    
                    <input type="submit" class="btn btn-primary" name="submit" value="Edit">
                </form>
            </div>
        </div>
        
        <!-- Akhir Container -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\latihanlaravel\resources\views//edit.blade.php ENDPATH**/ ?>