

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-4 mr-auto">

                <div class="row">
                    <div class="col-12 bg-white form-container">
                        <h2>Tabel Frekuensi</h2>
                        <table class="table">
                            <thead>
                                <tr>
                                    <td scope="col">Skor</td>
                                    <td scope="col">Frekuensi</td>
                                </tr>
                           </thead>
                           <tbody>
                               <?php $__currentLoopData = $frekuensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                               <tr>
                                   <td> <?php echo e($skor->skor); ?> </td>
                                   <td> <?php echo e($skor->frekuensi); ?></td>
                                </tr>
                                 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <b>Total Skor:</b>  </td>
                                    <td> <?php echo e($totalskor); ?></td>
                                </tr>
                                <tr>
                                    <td> <b>Total Frekuensi:</b>  </td>
                                    <td> <?php echo e($totalfrekuensi); ?></td>
                                </tr>
                           </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-7 ml-auto bg-white form-container">
                <form method="post" action="/" id="forminput">    
                    <h2>Silahkan Masukkan Skor</h2>
                    <br />
                    <div class="form-group">
                        <label for="input1">Nama Mahasiswa</label>
                        <input type="text" class="form-control"
                            placeholder="Masukkan Nama Mahasiswa" name="nama" required />
                    </div>
                    <div class="form-group">
                        <label for="input2">Skor</label>
                        <input type="text" class="form-control"
                            placeholder="Masukkan Skor" name="skor" required />
                    </div>
                    <input type="submit" class="btn btn-primary daftar-btn" name="submit" value="Input">  
                    
                    <?php echo csrf_field(); ?>
                    
                    <label for="max" class="ml-4">Skor Maks: <b><?php echo e($max); ?></b></label>
                    <label for="min" class="ml-4">Skor Min: <b><?php echo e($min); ?></b></label>
                    <label for="rata2" class="ml-4">Rata-Rata: <b><?php echo e($rata2); ?></b></label>
                </form>
                <br>
                <table class="table">
                    <thead>
                        <tr>
                            <td scope="col">No</td>
                            <td scope="col">Nama</td>
                            <td scope="col">Skor</td>
                            <td scope="col">Action</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>                             
                            <th scope="row"><?php echo e($loop->iteration); ?></th>     
                            <td><?php echo e($user->nama); ?></td>
                            <td><?php echo e($user->skor); ?></td>
                            <td>
                                <form name="delete" action="/delete/<?php echo e($user->id); ?>" method="POST">     
                                    <a href='/edit/<?php echo e($user->id); ?>' class="btn btn-outline-success">Edit</a> 
                                    <?php echo csrf_field(); ?>               
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-outline-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                          
                    </tbody>
                </table>                
            </div>
        </div>
    </div>
    <!-- Akhir Container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\latihanlaravel\resources\views//home.blade.php ENDPATH**/ ?>